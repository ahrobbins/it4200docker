<?php
include_once "header.php";
?>
			<h1>Welcome to our organization</h1>
			
	<p>Don't forget to check <a href="http://www.freewebsitetemplates.com">free website templates</a> every day, because we add a new free website template almost daily.</p>
	
	<p>You can remove any link to our websites from this template you're free to use the template without linking back to us.</p>
	
	<p>This is just a place holder so you can see how the site would look like.</p>
	
	<p>This is a template designed by free website templates for you for free you can replace all the text by your own text.</p>
			
<?			
include_once "footer.php";
?>			