<?php
include_once "header.php";
?>
			<h1>this is the donation page</h1>
<?			
include_once "footer.php";
?>			