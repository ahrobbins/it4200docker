<?php

//this is the header file

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
<title>Charity template</title>
</head>

<body>
<div id="container">
	<div id="header">
		<div id="logo_w1">Charitable</div>
		<div id="logo_w2">Organization</div>
		<div id="header_text">
			<p>Make a donation today and help 2000 children</p>
			<a href="http://www.freewebsitetemplates.com">Make a donation now !</a>
		</div>
		<ul>
			<li><a href="./index.php">Home</a></li>
			<li><a href="http://www.freewebsitetemplates.com">Who are we?</a></li>
			<li><a href="./donation.php">Make a donation</a></li>
			<li><a href="http://www.freewebsitetemplates.com">Our work</a></li>
			<li><a href="http://www.freewebsitetemplates.com">News &amp; press</a></li>
			<li><a href="http://www.freewebsitetemplates.com">Contact us</a></li>
		</ul>
	</div>
	<div id="content">
		<div id="left">
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		