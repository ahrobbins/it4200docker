<?php

//footer

$date = date("m d Y");
//echo $date;

?>
<h1>Photos</h1>
			<div id="photos">
			<a href="http://www.freewebsitetemplates.com"><img src="images/photo1.jpg" alt="photo" /></a>
			<a href="http://www.freewebsitetemplates.com"><img src="images/photo2.jpg" alt="photo" /></a>
			<a href="http://www.freewebsitetemplates.com"><img src="images/photo3.jpg" alt="photo" /></a>
			<a href="http://www.freewebsitetemplates.com"><img src="images/photo4.jpg" alt="photo" /></a>
			</div>
		</div>
		<div id="right">
			<h2>Latest news</h2>
			<a href="http://www.justwebtemplates.com">Just Web Templates</a>
			<p>Even more websites all about website templates on Just Web Templates.</p>
			<a href="http://www.templatebeauty.com">Template Beauty</a>
			<p>If you're looking for beautiful and professionally made templates you can find them at Template Beauty.</p>
			<a href="http://www.freewebsitetemplates.com/forum/">The forum</a>
			<p>If you're having problems editing the template please don't hesitate to ask for help on the forum.</p>
		</div>
		<div id="footerline"></div>
	</div>
	
	<div id="footer">Copyright &copy; <?=$date?> Charity Organization.  All rights reserved.</div>	
</div>
</body>
</html>













